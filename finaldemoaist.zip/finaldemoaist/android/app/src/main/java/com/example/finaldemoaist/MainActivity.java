package com.example.finaldemoaist;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
